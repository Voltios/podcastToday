@extends('index')
@section('autor')
    <h1>{{ $autor->name }}</h1>
@endsection
