
<?php $__env->startSection('crearEp'); ?>
    <div class="form-container crearProg">
        <?php if(session('mensaje')): ?>
            <div class="mensaje-prog">
                <?php echo e(session('mensaje')); ?>

            </div>
        <?php endif; ?>
        <h1>Insertar episodio en <?php echo e($programa->nombre); ?></h1>
        <form action="<?php echo e(route('anyadirEp')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <label class="nombreInput" for="nombre">Nombre</label><br>
            <input type="text" name="nombre">
            <br>
            <label for="descripcion">Descripción</label><br>
            <textarea cols="30" rows="10" type="text" name="descripcion"
                placeholder="Describe un poco el contenido del episodio"></textarea>
            <br>
            <label for="url">Url al episodio</label><br>
            <input type="text" name="url">
            <br>
            <?php echo e(Form::hidden('prog_id', $programa->id)); ?>

            
            <button type="submit" class="btn enviar">Enviar</button>
        </form>
        <a class="pa login" href="<?php echo e(route('home')); ?>">Volver al inicio</a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('forms', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /app/resources/views/episodes/crear.blade.php ENDPATH**/ ?>