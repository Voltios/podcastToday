
<?php $__env->startSection('episodios'); ?>
    <h1>Episodios de <?php echo e($programa->nombre); ?></h1>
    <?php $__currentLoopData = $episodios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ep): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="infoEp">

            <div class="episodio">
                <a href="<?php echo e($ep->url); ?>"> <p class="ep_nombre"><?php echo e($ep->nombre); ?></p></a>
                <p class="ep_descripcion"><?php echo e($ep->descripcion); ?></p>
            </div>
            <div class="btn-cont">
                <form action="<?php echo e(route('eliminarEps', $ep->id, $programa->id)); ?>" method="POST">
                    <?php echo method_field('DELETE'); ?>
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="addProgram borrar">Borrar</button>
                </form>
                <form action="<?php echo e(route('editarEps', $ep->id)); ?>">
                    <button type="submit" class="addProgram editar">Editar</button>
                </form>
            </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <a class="anyadirr" href="<?php echo e(route('anyadirEps', $programa->id)); ?>">Añadir episodio</a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /app/resources/views/episodes/infoEp.blade.php ENDPATH**/ ?>