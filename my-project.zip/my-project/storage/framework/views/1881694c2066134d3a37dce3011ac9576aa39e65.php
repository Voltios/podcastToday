
<?php $__env->startSection('autores'); ?>
    <h1>Descubrir autores</h1>

    <div class="authors">

        <?php $__currentLoopData = $autores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $autor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="author">
                <div class="author-image"><?php echo e($autor); ?></div>
                
            </div>

            <div class="author">Autorr</div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /app/resources/views/autores.blade.php ENDPATH**/ ?>