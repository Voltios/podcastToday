

<?php $__env->startSection('perfil'); ?>
    <div class="main-perfil">
        <h1 class="h1 title"><?php echo e($user->name); ?></h1>
        <?php if(Auth::id() == $user->id): ?>
            <a class="addProgram" href="<?php echo e(route('crearProg')); ?>">Añadir un programa</a>
        <?php endif; ?>
        <h2>Programas en los que aparece: </h2>
        <?php $__currentLoopData = $programas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="programa_creador">
                <div class="nombre_programa_creador">
                    <a href="<?php echo e(route('programa', $p->id)); ?>">
                        <span><?php echo e($p->nombre); ?></span>
                    </a>
                </div>
                <div class="descripcion_programa_creador">
                    <p><?php echo e($p->descripcion); ?></p>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <div class="temas_programas">
            <h2>También te puede gustar...</h2>
            <div class="temas_programas_container">

                <?php $__currentLoopData = $todosProgramas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('programa', $prog->id)); ?>">
                        <div class="tema_prog">
                            <h3><?php echo e($prog->nombre); ?></h3>
                            <span class="puntuacion"><?php echo e($prog->puntuacion); ?></span>
                        </div>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /app/resources/views/profile.blade.php ENDPATH**/ ?>