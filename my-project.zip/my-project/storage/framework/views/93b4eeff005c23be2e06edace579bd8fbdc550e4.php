
<?php $__env->startSection('register'); ?>
    <?php if(session('mensaje')): ?>
        <?php echo e(session('mensaje')); ?>

    <?php endif; ?>
    <form action="<?php echo e(route('register')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <label for="fname">nombre
            <input type="text" name="fname" id="fname">
        </label>
        <label for="fpaswd">paswd
            <input type="password" name="fpaswd" id="fpaswd">
        </label>
        <label for="fuser">user
            <input type="text" name="fuser" id="fuser">
        </label>
        <label for="furl">url
            <input type="url" name="furl" id="furl">
        </label>
        <label for="femail">email
            <input type="email" name="femail" id="femail">
        </label>
        <input type="submit" value="Enviar">
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('forms', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /app/resources/views/cred/register.blade.php ENDPATH**/ ?>