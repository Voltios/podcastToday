
<?php $__env->startSection('crear'); ?>
    <div class="form-container crearProg">
        <h2 class="title">Añadir un programa</h2>
        <?php if(session('mensaje')): ?>
            <div class="mensaje-prog">
                <?php echo e(session('mensaje')); ?>

            </div>
        <?php endif; ?>
        <form action="<?php echo e(route('crear')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <label for="fnom">Nombre del programa

                <input type="text" name="fnom" placeholder="" class="form-input-text" autofocus>
            </label>
            <br>
            <label for="fdesc">Descripción del programa

                <textarea id='textarea' name="fdesc" cols="35" rows="10" placeholder="Cuéntale al mundo de qué va tu programa"
                    class="form-input-textarea"></textarea>
                <br>
                <span id="maxChar">500</span>
                <br>
            </label>

            <label for="furl">Enlace al programa
                <input type="url" name="furl" placeholder="https://www.ejemplo.com">
            </label>

            <div class="cat_container">
                <label for="">Categorias</label>
                <br>
                <div class="categoriasCheck">
                    <?php $__currentLoopData = $cat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="categoria">

                            <input name="categorias[]" class="checkbox" type="checkbox" value="<?php echo e($c->id); ?>">
                            <label for="fcat" class=""><?php echo e($c->nombre); ?> </label>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <div class="info">
                <p class="">¿No hay un tema que se adapte al contenido de tu programa?</p>
                <a href="mailto:ales.volivares@gmail.com?subject=Falta%20categoría">Escríbenos!</a>
            </div>
            
            <div class="cc">
                <input class="btn enviar" type="submit" value="Enviar!">
            </div>
        </form>
        <a class="pa login" href="<?php echo e(route('home')); ?>">Volver al inicio</a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('forms', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /app/resources/views/programs/crear.blade.php ENDPATH**/ ?>