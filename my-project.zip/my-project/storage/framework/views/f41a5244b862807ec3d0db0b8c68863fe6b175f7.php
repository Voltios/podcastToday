
<?php $__env->startSection('editarPrograma'); ?>
    <div class="form-container crearProg">
        <h2 class="title">Editar programa</h2>
        <?php if(session('mensaje')): ?>
            <div class="mensaje-prog">
                <p><?php echo e(session('mensaje')); ?></p>
            </div>
        <?php endif; ?>
        <form action="<?php echo e(route('actualizarPrograma', $programa->id)); ?>" method="POST"></form>
        <?php echo method_field('PUT'); ?>
        <?php echo csrf_field(); ?>

        <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="error">
                El nombre es obligatorio
            </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <?php $__errorArgs = ['descripcion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            La descripción es obligatoria
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <form action="<?php echo e(route('actualizarPrograma', $programa->id)); ?>" method="POST">
            <?php echo method_field('PUT'); ?>
            <?php echo csrf_field(); ?>
            <label for="nombre">Nombre del programa</label>
            <input type="text" name="nombre" class="" value="<?php echo e($programa->nombre); ?>"
                placeholder="Nombre del programa..." autofocus>
            <br>
            <label for="descripcion">Descripción del programa</label><br>
            <textarea name="descripcion" cols="30" rows="10"><?php echo e($programa->descripcion); ?></textarea>

            <br>
            <label for="enviar">
                <button class="btn enviar" type="submit"> <i class="fas fa-check"></i> Enviar</button>
            </label>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('forms', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /app/resources/views/programs/editar.blade.php ENDPATH**/ ?>