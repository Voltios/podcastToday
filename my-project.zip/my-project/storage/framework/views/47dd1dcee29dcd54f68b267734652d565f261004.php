
<?php $__env->startSection('temas'); ?>
    <h1>Descubrir temas</h1>

    <div class="topics">
        <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="topic"><?php echo e($cat->nombre); ?>

                <a class="topicRef" href="<?php echo e(route('progTema', $cat->nombre)); ?>">IR</a>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div class="temas_programas">
        <h2>También te puede gustar...</h2>
        <div class="temas_programas_container">

            <?php $__currentLoopData = $todosProgramas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('programa', $prog->id)); ?>">
                    <div class="tema_prog">
                        <h3><?php echo e($prog->nombre); ?></h3>
                        <span><?php echo e($prog->puntuacion); ?></span>
                    </div>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /app/resources/views/programs/temas.blade.php ENDPATH**/ ?>