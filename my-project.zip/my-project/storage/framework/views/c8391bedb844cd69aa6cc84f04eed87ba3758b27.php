<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, maximum-scale=1, initial-scale=1.0, user-scalable=0">


    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css"
        integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="shortcut icon"
        href="https://upload.wikimedia.org/wikipedia/commons/thumb/8/80/High-contrast-audio-input-microphone.svg/2048px-High-contrast-audio-input-microphone.svg.png"
        type="image/x-icon">
    <link rel="stylesheet" href="https://cdn-uicons.flaticon.com/uicons-solid-rounded/css/uicons-solid-rounded.css">


    <link rel="stylesheet" href="<?php echo e(asset('css/styles.css')); ?>">

    <title>PodcastToday</title>
</head>

<div class="cursor" id="biCur"></div>

<body class="light">
    
    <div class="e"></div>
    <nav class="light" id="navbar">
        <div class="la">
            <i class="fa fa-angles-down" id="flecha" aria-hidden="true"></i>
        </div>
        <ul class="actions nav-list-65 list">
            <li>
                <a class="light" href="<?php echo e(route('home')); ?>"><span><i
                            class="fa-solid fa-star"></i></span>Destacado</a>
            </li>
            <li>
                <a href="<?php echo e(route('autores')); ?>"><span><i class="fa-solid fa-at"></i></span>Autores</a>
            </li>
            <li>
                <a href="<?php echo e(route('temas')); ?>"><span><i class="fa-solid fa-message"></i></span>Categorías</a>
            </li>
            <!--
            <li>
                <select name="lang" id="">
                    <option value="ES">Español</option>
                    <option value="EN">English</option>
                    <option value="CA">Catalán / Valenciano</option>
                </select>
            </li> -->
            <li>
                <a href="<?php echo e(route('programas')); ?>" id=""><span><i
                            class="fa-solid fa-microphone"></i></span>Descubrir</a>
                <!-- <img src="Grupo 30.svg" alt="lunica" height="20"> -->
            </li>
        </ul>
        <?php if(auth()->guard()->guest()): ?>
            <?php if(Route::has('login')): ?>
                <ul class="nav-list-35 list">
                    <li class="">
                        <a href="<?php echo e(route('login')); ?>"><span><i class="  fa-solid fa-user"></i></span>Iniciar sesión</a>
                    </li>
                    <li class="register">
                        <a href="<?php echo e(route('register')); ?>"><span><i class="fa-solid fa-plus"></i></span>Registrarse</a>
                    </li>

                </ul>
            <?php endif; ?>
        <?php else: ?>
            <ul class="nav-list-35 list">
                <li class="">
                    <a class="nombreUsuario" href="<?php echo e(route('profile', Auth::id())); ?>"><span><i
                                class="fa-solid fa-user"></i><?php echo e(Auth::user()->username); ?></span></a>
                </li>
                <li>
                    <a class="logout" href="<?php echo e(route('logout')); ?>"
                        onclick="event.preventDefault(); document.getElementById('logout-form').submit();"
                        href="logg"><span> <i class="fa fa-power-off" aria-hidden="true"></i>Salir</span></a>
                    <form action="<?php echo e(route('logout')); ?>" method="POST" id="logout-form">
                        <?php echo csrf_field(); ?>
                    </form>
                </li>
            </ul>
        <?php endif; ?>

    </nav>
    <main>

        <div class="caja">
            <?php if(isset($programa)): ?>
                <img id="img" src="<?php echo e(asset('storage/cover_' . $programa->id . '.jpg')); ?>" height="200" alt="algo">
            <?php endif; ?>
        </div>


        <?php echo $__env->yieldContent('inicio'); ?>
        <?php echo $__env->yieldContent('temas'); ?>
        <?php echo $__env->yieldContent('autores'); ?>
        <?php echo $__env->yieldContent('perfil'); ?>
        <?php echo $__env->yieldContent('login'); ?>
        <?php echo $__env->yieldContent('programa'); ?>
        <?php echo $__env->yieldContent('progTema'); ?>
        <?php echo $__env->yieldContent('episodios'); ?>
        <?php echo $__env->yieldContent('listaPrgs'); ?>
    </main>
    <footer>

        <div class="colores">
            <div id="c1"></div>
            <div id="c2"></div>
            <div id="c3"></div>
        </div>
    </footer>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.10.2/gsap.min.js"></script>
    <script src="<?php echo e(asset('js/thief.js')); ?>"></script>
    <script src="<?php echo e(asset('js/navbar.js')); ?>"></script>
    <script src="<?php echo e(asset('js/cursor.js')); ?>"></script>

</body>

</html>
<?php /**PATH /app/resources/views/index.blade.php ENDPATH**/ ?>