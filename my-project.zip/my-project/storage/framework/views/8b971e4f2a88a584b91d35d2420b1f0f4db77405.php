
<?php $__env->startSection('listaPrgs'); ?>
    <h1 class="title">Lista de programas</h1>
    <div class="lista_container">

        <?php $__currentLoopData = $progs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="lista_programa">
                <a href="<?php echo e(route('programa', $prog->id)); ?>">
                    <img src="<?php echo e(asset('storage/cover_' . $prog->id . '.jpg')); ?>" height="150" width="150"
                        alt="cover <?php echo e($prog->nombre); ?>">
                </a>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /app/resources/views/programs/listaProgramas.blade.php ENDPATH**/ ?>