
<?php $__env->startSection('crearEp'); ?>
    <div class="form-container crearProg">
        <h1>Editar episodio <?php echo e($ep->nombre); ?></h1>
        <form action="<?php echo e(route('editarEp', $ep->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <label for="nombre">Nombre</label><br>
            <input type="text" class="nombreInput" name="nombre" value="<?php echo e($ep->nombre); ?>"><br>
            <label for="descripcion">Descripción</label><br>
            <textarea name="descripcion" id="" cols="30" rows="10"><?php echo e($ep->descripcion); ?></textarea>
            <br>
            <button type="submit" class="btn enviar">Enviar</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('forms', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /app/resources/views/episodes/editar.blade.php ENDPATH**/ ?>