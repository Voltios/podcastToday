
<?php $__env->startSection('autores'); ?>
    <h1>Descubrir autores</h1>
    <p>Pulsa en el nombre para acceder al perfil</p>
    <div class="authors">
        <?php $__currentLoopData = $autores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $autor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="author">
                
                <a class="author_name" href="<?php echo e(route('profile', $autor->id)); ?>"><span><?php echo e($autor->name); ?></span></a>
                <span class="author_desc"><?php echo e($autor->descripcion); ?></span>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /app/resources/views/programs/autores.blade.php ENDPATH**/ ?>