
<?php $__env->startSection('programa'); ?>
    <h1 class="title"><?php echo e($programa->nombre); ?></h1>
    <img class="imgCover" 
     src=<?php echo e(asset('storage/cover_' . $programa->id . '.jpg')); ?>

        alt="<?php echo e(__('cover ' . $programa->nombre)); ?>">
        <div class="podcast-description">
            <p><?php echo e($programa->descripcion); ?></p>
        </div>
    <div class="infoEp">
        <h2>Episodios:</h2>
        <?php $__currentLoopData = $episodios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ep): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="episodio">
                <a href="<?php echo e($ep->url); ?>">
                    <p class="ep_nombre"><?php echo e($ep->nombre); ?></p>
                </a>
                <p class="ep_descripcion"><?php echo e($ep->descripcion); ?></p>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <p>Puntuación mensual: <span class="puntuacion"><?php echo e($programa->puntuacion); ?></span></p>

        <form action="<?php echo e(route('votar', $programa->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <button class="botton" type="submit">Votar +1</button>
        </form>
    </div>
    <?php if(Auth::user() && $programa->user_id == Auth::user()->id): ?>
        <div class="acciones">
            <form action="<?php echo e(route('editarPrograma', $programa->id)); ?>">
                <button type="submit" class="btn botton">Editar</button>
            </form>

            <form action="<?php echo e(route('modificarEpisodios', $programa->id)); ?>">
                <button type="submit" class="btn botton">Modificar episodios</button>
            </form>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /app/resources/views/programs/infoPd.blade.php ENDPATH**/ ?>