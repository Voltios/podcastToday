
<?php /**PATH /app/resources/views/home.blade.php ENDPATH**/ ?>