
<?php $__env->startSection('inicio'); ?>
    <h1><?php echo e($programa->nombre); ?></h1>
    <h2>Programa destacado</h2>

    <div class="podcast-content">
        <div class="info-content">

            <img class="imgCover" src="<?php echo e(asset('storage/cover_' . $programa->id . '.jpg')); ?>"
                alt="cover <?php echo e($programa->nombre); ?>" height="200px">
            <p class="podcast-description">
                <?php echo e($programa->descripcion); ?>

            </p>

            <h3>Valoración mensual <span class="puntuacion"><?php echo e($programa->puntuacion); ?></span></h3>

        </div>
        <div class="action-btns" id="progRef">
            <a id="." href="<?php echo e(route('programa', $programa->id)); ?>">Ir al programa</a>
        </div>
        <div class="action-btns" id="externalLink">
            <a class="action-btn" id="externalLink" href="<?php echo e($programa->url); ?>">Escuchar ahora!</a>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /app/resources/views/inicio.blade.php ENDPATH**/ ?>